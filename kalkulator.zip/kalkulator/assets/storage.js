// const CACHE_KEY = "calculation_history";

// function checkForStorage(){
//     return typeof(Storage) !== "undefined"
// }

// function putHistory(data){
//     if(checkForStorage()){
//         let history_data = null;
//         if(localStorage.getItem(CACHE_KEY) === null){
//             history_data = [];
//         }else{
//             history_data = JSON.parse(localStorage.getItem(CACHE_KEY));
//         }

//         history_data.unshift(data);
//         if(history_data.length > 5){
//             history_data.pop();
//         }

//         localStorage.setItem(CACHE_KEY, JSON.stringify(history_data));
//     }
// }

// function showHistory(){
//     if(checkForStorage()){
//         return JSON.parse(localStorage.getItem(CACHE_KEY)) || [];
//     }else{
//         return [];
//     }
// }

// function renderHistory(){
//     const history_data = showHistory();
//     let historyList = document.querySelector('#historyList');

//     // Selalu hapus konten HTML pada elemen historyList agar tidak menampilkan data ganda
//     historyList.innerHTML = "";
//     for(let history of history_data){
//         let row = document.createElement('tr');
//         row.innerHTML = "<td>" + history.firstNumber + "</td";
//         row.innerHTML = "<td>" + history.operator + "</td";
//         row.innerHTML = "<td>" + history.secondNumber + "</td>";
//         row.innerHTML = "<td>" + history.result + "</td>";

//         historyList.appendChild(row);
//     }
// }

// renderHistory();







